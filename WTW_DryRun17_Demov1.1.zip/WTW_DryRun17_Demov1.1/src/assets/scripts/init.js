/**
 * Created by adhabale on 7/3/2017.
 */
$(document).ready(function() {
  $('select').niceSelect();

});
