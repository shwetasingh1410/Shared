import { Component,Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 active='Market Security';
  passive='Market Security Admin';
  isAdminActive=false;
  isUserActive=true;
  url='url';
headervalue;
  constructor(@Inject(DOCUMENT) private document: any) {
  this.hitme();
}

hitme(){
  this.url=this.document.location.href;
  this.url=this.url.substring(22);

  if(this.url=='home' || this.url=='#'){
    this.headervalue='Welcome To Market Security';
  }

  if(this.url=='disclaimers'){
    this.headervalue='Disclaimers';
  }
  if(this.url=='ratings'){
    this.headervalue='Rating Scale';
  }
  if(this.url=='edituser'){
    this.headervalue='User Maintenance';
  }
  if(this.url=='announcements'){
    this.headervalue='Announcements';
  }
  if(this.url=='carriersearch'){
    this.headervalue='Carrier Search';
  }
  if(this.url=='notification'){
    this.headervalue='Client Notification';
  }
  if(this.url=='carrier-doc'){
    this.headervalue='Client Documents';
  }
  if(this.url=='homepageAdmin'){
    this.headervalue='Home Page - Admin';
  }
  if(this.url=='carrierfavorites'){
    this.headervalue='Carrier Favorites';
  }
  if(this.url=='clientmaintainance'){
    this.headervalue='Client Maintenance';
  }
}

  activeComp(data){
    console.log(data);
    if(data=='Market Security Admin'){
      this.active='Market Security Admin';
      this.passive='Market Security';
      this.isAdminActive=true;
      this.isUserActive=false;
    }
    else {
      this.passive='Market Security Admin';
      this.active='Market Security';
      this.isAdminActive=false;
    this.isUserActive=true;
    }
  }
}
