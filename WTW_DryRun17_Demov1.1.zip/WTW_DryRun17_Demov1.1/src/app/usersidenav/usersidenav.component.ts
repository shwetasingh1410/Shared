import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usersidenav',
  templateUrl: './usersidenav.component.html',
  styleUrls: ['./usersidenav.component.css']
})
export class UsersidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
