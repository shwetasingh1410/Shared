import { Component } from '@angular/core';

@Component({
    selector: 'app-carrierfavorites',
    templateUrl: './carrierfavorites.component.html',
    styleUrls: ['./carrierfavorites.component.css']
})
export class CarrierfavoritesComponent {

   /* selectMode = false;
    selectType = false;
    selectCreationType = false;
    selectionModeSuccess = false;*/
    showTable = false;
    /*
    showCategory = false;

    openSelectModeClicked() {
        this.selectMode = true;
        this.selectType = true;
    }

    openSelectModeClientClicked() {
        this.selectType = false;
        this.selectCreationType = true;
    }

    completeSelectModeClientClicked() {
        this.selectCreationType = false;
        this.selectionModeSuccess = true;
    }*/
    selectionSuccess() {
        /*this.selectionModeSuccess = false;
        this.selectMode = false;*/
        this.showTable = true;
    }
/*
    cancelSelectionMode() {
        this.selectMode = false;
        this.selectType = false;
        this.selectCreationType = false;
        this.selectionModeSuccess = false;
        this.selectMode = false;
    }

    openCategorySelection() {
        this.showCategory = true;
    }

    closeCategorySelection() {
        this.showCategory = false;
    }*/
}   
