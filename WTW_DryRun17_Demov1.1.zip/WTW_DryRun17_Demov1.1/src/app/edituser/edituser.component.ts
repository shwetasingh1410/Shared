import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

isSearchVisible=false;
isTableVisible=false;
showRoles=false;
showDetails=false;
isroleopen=true;
isdetailsopen=true;
flag=true;

clients=[{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'}];
clientscopy=[{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'}];
client;
  constructor(private _router:Router) { }

  ngOnInit() {
  }

  contentload(text){
    this.isSearchVisible=true;
    this.isTableVisible=false;
  }

  searchload() {
    this.isTableVisible=true;
  }

  selectload() {
    this.isTableVisible=false;
    this.showDetails=true;
    this.isdetailsopen=false;
  }

  saverole() {
    this.isroleopen=false;
    this.showRoles=true;
  }

  saverecord() {
    alert("Saved Successfully!!!");
    this._router.navigate(['']);
  }

  selectremove() {
    
  }

  selectadd(data) {
    if(this.clientscopy.length!=0){
      for(var i=0;i<this.clientscopy.length;i++) {
      if(this.clientscopy[i].name == data){
        console.log('Nothing new to add');
        this.flag=false;
      }
    }
  }
  if(this.flag) {
    this.client="{name:"+data+"}";
    this.clientscopy.push(this.client);
    console.log(this.clientscopy);
  }
  }

}
