import { Component, OnInit,Inject} from '@angular/core';
import $ from 'jQuery';
import { DOCUMENT } from '@angular/platform-browser';
@Component({
  selector: 'app-carriersearch',
  templateUrl: './carriersearch.component.html',
  styleUrls: ['./carriersearch.component.css']
})
export class CarriersearchComponent implements OnInit {
  isClientSelected=false;
  isTableSelected=false;
  url='url';
  constructor(@Inject(DOCUMENT) private document: any) {
    this.url=this.document.location.href;
    console.log(this.url.substring(22));
  }

  ngOnInit() {
    console.log('carrier');
    $.getScript('./assets/scripts/init.js');
  }

  selectclient() {
    $.getScript('./assets/scripts/init.js');
    this.isClientSelected=true;
    this.isTableSelected=false;
  }

  findresults(){
    this.isTableSelected=true;
  }


}
