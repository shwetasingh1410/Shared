import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarriersearchComponent } from './carriersearch.component';

describe('CarriersearchComponent', () => {
  let component: CarriersearchComponent;
  let fixture: ComponentFixture<CarriersearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarriersearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarriersearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
