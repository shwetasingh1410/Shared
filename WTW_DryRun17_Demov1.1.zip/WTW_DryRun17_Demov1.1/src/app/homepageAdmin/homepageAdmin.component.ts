import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepageAdmin',
  templateUrl: './homepageAdmin.component.html',
  styleUrls: ['./homepageAdmin.component.css']
})
export class HomePageAdminComponent implements OnInit {
  text: string;
  constructor() { 
  }

  ngOnInit() {
  }

}

