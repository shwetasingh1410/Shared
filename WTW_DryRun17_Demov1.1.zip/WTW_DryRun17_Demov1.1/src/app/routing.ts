import { Router , RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { RatingsComponent } from './ratings/ratings.component';
import { DisclaimersComponent } from './disclaimers/disclaimers.component';
import { EdituserComponent } from './edituser/edituser.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { CarriersearchComponent } from './carriersearch/carriersearch.component';
import { NotificationComponent } from './notification/notification.component';
import { CarrierDocComponent } from './carrier-doc/carrier-doc.component';
import { HomePageAdminComponent } from './homepageAdmin/homepageAdmin.component';
import { CarrierfavoritesComponent } from './carrierfavorites/carrierfavorites.component';
import { ClientMaintainanceComponent } from './clientmaintainance/clientmaintainance.component';


export const routing = RouterModule.forRoot([
    { path: 'home', component: HomeComponent},
    { path: 'disclaimers', component: DisclaimersComponent},
    { path: 'ratings', component: RatingsComponent},
    { path: 'edituser', component: EdituserComponent},
    { path: 'announcements', component: AnnouncementsComponent},
    { path: 'carriersearch', component: CarriersearchComponent},
    {path : 'notification', component : NotificationComponent },
    {path : 'carrier-doc', component : CarrierDocComponent },
    {path : 'homepageAdmin', component : HomePageAdminComponent},
    {path : 'carrierfavorites', component : CarrierfavoritesComponent},
    {path : 'clientmaintainance', component : ClientMaintainanceComponent},
    { path: '**', redirectTo:'\home'},
]);