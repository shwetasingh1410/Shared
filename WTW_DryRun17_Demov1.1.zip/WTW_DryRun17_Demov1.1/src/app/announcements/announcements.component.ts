import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.css']
})
export class AnnouncementsComponent implements OnInit {

isTableVisible=true;
isCreateAnnouncementVisible=false;
available=[{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'},{name:'ABB Hongkong Limited (212323)'},{name:'Swiss Life (Espana) (232342)'},{name:'Farmers Insurance (453412)'},{name:'Zenith Insurance (124512)'}];
assigned=[];

  constructor() { }

  ngOnInit() {
  }

  create(){
    this.isTableVisible=false;
    this.isCreateAnnouncementVisible=true;
  }
  add(data) {
    // this.assigned.push({'name':data});
    // console.log(this.assigned);
    console.log(data);
    
  }
}
