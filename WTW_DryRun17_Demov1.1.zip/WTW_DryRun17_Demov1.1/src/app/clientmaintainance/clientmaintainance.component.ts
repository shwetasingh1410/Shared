import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientmaintainance',
  templateUrl: './clientmaintainance.component.html',
  styleUrls: ['./clientmaintainance.component.css']
})
export class ClientMaintainanceComponent implements OnInit {
isviewhidden=false;
  constructor() { }

  ngOnInit() {
  }
	
showmagic() {
	this.isviewhidden=true;
}

}
